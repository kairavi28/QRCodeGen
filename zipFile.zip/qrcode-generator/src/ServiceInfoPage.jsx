// ServiceInfoPage.jsx
import React from "react";
import { useLocation } from "react-router-dom";
import { Box, Typography, Button, Card, CardContent, Divider } from "@mui/material";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";

export default function ServiceInfoPage() {
  const { search } = useLocation();
  const params = new URLSearchParams(search);
  const data = params.get("data");
  const serviceData = data ? JSON.parse(decodeURIComponent(data)) : {};

  const handleDownloadPDF = () => {
    const input = document.getElementById("service-card");
    html2canvas(input).then((canvas) => {
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF("p", "mm", "a4");
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
      pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
      pdf.save(`${serviceData.productName || "service-info"}.pdf`);
    });
  };

  // Determine map URL safely
  const mapSrc = serviceData.location
    ? serviceData.location.lat && serviceData.location.lng
      ? `https://www.google.com/maps?q=${serviceData.location.lat},${serviceData.location.lng}&z=15&output=embed`
      : `https://www.google.com/maps?q=${encodeURIComponent(serviceData.location.address)}&z=15&output=embed`
    : null;

  return (
    <Box sx={{ minHeight: "100vh", bgcolor: "#f9fafb", display: "flex", justifyContent: "center", alignItems: "center", p: 2 }}>
      <Card id="service-card" elevation={5} sx={{ maxWidth: 500, width: "100%", borderRadius: 4, overflow: "hidden" }}>
        {/* Header */}
        <Box sx={{ bgcolor: "#003366", color: "white", textAlign: "center", py: 3 }}>
          <img src="/biomed-logo.png" alt="Biomed Logo" style={{ height: 60, marginBottom: 8 }} />
          <Typography variant="h6">Serviced by Biomed Recovery & Disposal Ltd.</Typography>
        </Box>

        <CardContent>
          {/* Product Name */}
          <Typography variant="h5" fontWeight="bold" gutterBottom>
            {serviceData.productName || "Product Name"}
          </Typography>
          <Divider sx={{ mb: 2 }} />

          {/* Service Info */}
          {serviceData.lastServiced && (
            <Typography variant="body1"><strong>Last Serviced:</strong> {serviceData.lastServiced}</Typography>
          )}
          
          {serviceData.servicedBy && (
            <Typography variant="body1"><strong>Technician:</strong> {serviceData.servicedBy}</Typography>
          )}

          {/* Location & Map */}
          {serviceData.location?.address && (
            <>
              <Typography variant="body1" sx={{ mt: 2, mb: 1 }}>
                <strong>Location:</strong> {serviceData.location.address}
              </Typography>

              {mapSrc && (
                <Box sx={{ position: "relative", pb: "56.25%", height: 0, overflow: "hidden", borderRadius: 2, mb: 2 }}>
                  <iframe
                    title="Google Map"
                    src={mapSrc}
                    style={{ position: "absolute", top: 0, left: 0, width: "100%", height: "100%", border: 0 }}
                    allowFullScreen
                    loading="lazy"
                  />
                </Box>
              )}
            </>
          )}

          {/* Product Link */}
          {serviceData.productLink && (
            <Button variant="contained" color="primary" href={serviceData.productLink} target="_blank" fullWidth sx={{ mt: 2 }}>
              View Product
            </Button>
          )}

          {/* Download PDF */}
          <Button variant="outlined" color="secondary" fullWidth sx={{ mt: 2 }} onClick={handleDownloadPDF}>
            Download PDF
          </Button>
        </CardContent>

        {/* Footer */}
        <Box sx={{ bgcolor: "#f1f5f9", py: 1, textAlign: "center" }}>
          <Typography variant="caption" color="text.secondary">
            © {new Date().getFullYear()} Biomed Recovery & Disposal Ltd.
          </Typography>
        </Box>
      </Card>
    </Box>
  );
}
